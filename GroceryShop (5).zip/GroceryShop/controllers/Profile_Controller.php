<?php

session_start();
$username = $_SESSION['username'];

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: ../login.php");
    exit();
}


require_once 'ConnectionManager.php';


function createProfileTable($conn) {
    $createTableQuery = "CREATE TABLE IF NOT EXISTS user_profile (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255) UNIQUE NOT NULL,
        image_path VARCHAR(255), 
        image_content LONGBLOB, 
        full_name VARCHAR(255), 
        bio TEXT,
        dob DATE, 
        date_of_create TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if (mysqli_query($conn, $createTableQuery)) {
        echo 'Table created or already exists.';
    } else {
        echo "Error creating table: " . mysqli_error($conn);
    }
}


function createData($username, $conn) {

    $SQL = "INSERT INTO user_profile (username) VALUES (?)";

    $stmt = mysqli_prepare($conn, $SQL);
    mysqli_stmt_bind_param($stmt, "s", $username);

    if (mysqli_stmt_execute($stmt)) {
        mysqli_stmt_close($stmt);
        return true; 
    } else {
        mysqli_stmt_close($stmt);
        return false; 
    }
}


function uploadProfileImage($conn, $username) {

    if (isset($_FILES['profileImage']) && !empty($_FILES['profileImage']['name'])) {

        //echo $_FILES['profileImage'];
        //die();

        $targetDirectory = "../images/profile_images/"; 
        $targetFile = $targetDirectory . basename($_FILES["profileImage"]["name"]);
        
        // Check if the file is an image
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        if (getimagesize($_FILES["profileImage"]["tmp_name"]) === false) {
            echo '<script>alert("File is not an image.");</script>';
            header("Location: ../profile.php");
        }
        
        // Check file size (you can adjust the size limit)
        if ($_FILES["profileImage"]["size"] > 500000) {
            echo '<script>alert("File is too large.");</script>';
            header("Location: ../profile.php");
        }
        
        // Read image content
        $imageContent = file_get_contents($_FILES["profileImage"]["tmp_name"]);

        // Upload the image file to the local drive
        if (move_uploaded_file($_FILES["profileImage"]["tmp_name"], $targetFile)) {
            $updateImageQuery = "UPDATE user_profile SET image_path = ?, image_content = ? WHERE username = ?";
            $stmt = mysqli_prepare($conn, $updateImageQuery);
            mysqli_stmt_bind_param($stmt, "sss", $targetFile, $imageContent, $username);
            
            if (mysqli_stmt_execute($stmt)) {
                //echo "Image uploaded successfully.";
                header("Location: ../profile.php");
            } else {
                echo "Error updating image: " . mysqli_error($conn);
                echo'<script>alert("Failed to insert profile images");</script>';
                header("Location: ../profile.php");
            }
            
            mysqli_stmt_close($stmt);
        } else {
            echo "Error uploading image.";
        }
    }else{
        echo 'file not found!';
    }
}

// Create a database connection
$connectionManager = new ConnectionManager();
$conn = $connectionManager->getConnection();

createProfileTable($conn);

if(isset($_POST['updateProfilePic'])){

    $checkUserQuery = "SELECT id FROM user_profile WHERE username = ?";
    $stmt = mysqli_prepare($conn, $checkUserQuery);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {

        uploadProfileImage($conn, $username);

    } else {
    
        if (createData($username, $conn)) {
            echo "Data inserted successfully.";
            uploadProfileImage($conn, $username);
        } else {
            echo "Failed to insert data.";
        }  
    }



}


if (isset($_POST['profile_info_update'])) {
    // Get the form data
    $fullName = $_POST['fullName'];
    $dob = $_POST['date_of_birth'];
    $bio = $_POST['bio'];
    $username = $_SESSION['username'];

    $updateQuery = "UPDATE user_profile SET full_name = ?, bio = ?, dob=? WHERE username = ?";
    $stmt = mysqli_prepare($conn, $updateQuery);
    mysqli_stmt_bind_param($stmt, "ssss", $fullName, $bio, $dob, $username);
    
    if (mysqli_stmt_execute($stmt)) {
        echo '<script>alert("Profile information updated successfully.");</script>';
        header("Location: ../profile.php");
    } else {
        echo '<script>alert("Error updating profile information: ' . mysqli_error($conn) . '");</script>';
        header("Location: ../profile.php");
    }
    
    mysqli_stmt_close($stmt);
}



mysqli_close($conn);


?>
