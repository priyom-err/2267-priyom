<?php

    require_once('ConnectionManager.php');


    function createMessageTableIfNeeded($connection) {
        $sql = "CREATE TABLE IF NOT EXISTS messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            email VARCHAR(255) NOT NULL,
            msg TEXT NOT NULL,
            date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";

        if (mysqli_query($connection, $sql)) {
            return true;
        } else {
            return false;
        }
    }


    function insertMessage($connection, $name, $email, $message) {
        $sql = "INSERT INTO messages (name, email, msg) VALUES ('$name', '$email', '$message')";

        if (mysqli_query($connection, $sql)) {
            return true;
        } else {
            return false;
        }
    }


    if ($_SERVER["REQUEST_METHOD"] == "POST") {

        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        $connectionManager = new ConnectionManager();
        $connection = $connectionManager->getConnection();

        if ($connection) {

            if (createMessageTableIfNeeded($connection)) {

                if (insertMessage($connection, $name, $email, $message)) {
                    //echo "Message sent successfully!";
                    header('location: ../contact.php?sentsucc');
                } else {
                    //echo "Error inserting message: " . mysqli_error($connection);
                    header('location: ../contact.php?sentfailed');
                }
            } else {
                echo "Error creating message table: " . mysqli_error($connection);
            }

            mysqli_close($connection);
        } else {
            echo "Database connection failed.";
        }
    }


?>
