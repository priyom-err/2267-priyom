<?php

class ConnectionManager {
    private $conn;

    function __construct() {
        $host = "localhost";
        $username = "root";
        $password = "";
        $database = "grocerySHOP";

        // Create a connection to MySQL
        $this->conn = mysqli_connect($host, $username, $password);

        if (!$this->conn) {
            die("Connection failed: " . mysqli_connect_error());
        }

        $dbCheckQuery = "CREATE DATABASE IF NOT EXISTS $database";

        if(!mysqli_query($this->conn, $dbCheckQuery)){
            die("Error creating database: " . mysqli_error($this->conn));
        }

        if(!mysqli_select_db($this->conn, $database)){
            die("Error selecting database: " . mysqli_error($this->conn));
        }
    }

    function getConnection(){
        return $this->conn;
    }
}

































?>