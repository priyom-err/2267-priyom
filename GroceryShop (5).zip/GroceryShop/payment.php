
<?php 
    include('layouts/header.php'); 
    require_once 'controllers/ConnectionManager.php';

    // Create a database connection
    $connectionManager = new ConnectionManager();
    $conn = $connectionManager->getConnection();

    $quantity = '';
    $product_id = '';
    $price = '';

    if (isset($_POST['orderbtn'])) {
        $quantity = $_POST['quantity'];
        $product_id = $_POST['product_id'];
        $price = $_POST['price'];
    }

    function getFullName($conn, $username){
        try {
            $query = "SELECT `full_name` FROM `user_profile` WHERE `username` = ?";
            $stmt = $conn->prepare($query);
    
            if ($stmt) {
                $stmt->bind_param('s', $username);
                $stmt->execute();
    
                $stmt->bind_result($fullName);
                $stmt->fetch();
                $stmt->close();
                return $fullName;
            } else {
                throw new Exception("Statement preparation failed.");
            }
        } catch (Exception $e) {
            return null;
        }
    }
    

    function getUserEmail($conn, $username) {
        $query = "SELECT `email` FROM `registration` WHERE `username` = ?";
        $stmt = $conn->prepare($query);
    
        if ($stmt) {
            $stmt->bind_param('s', $username);
            $stmt->execute();
    
            $stmt->bind_result($email);
            $stmt->fetch();
            $stmt->close();
            return $email;
        } else {
            return null;
        }
    }

    function separateFullName($fullName) {
        $parts = explode(' ', $fullName, 2);
    
        if (count($parts) === 1) {
            $firstName = $parts[0];
            $lastName = '';
        } else {
            $firstName = $parts[0];
            $lastName = $parts[1];
        }
    
        return array('first_name' => $firstName, 'last_name' => $lastName);
    }
    
    
    $username = $_SESSION['username'];
    $fullName = getFullName($conn, $username);
    $email = getUserEmail($conn, $username);

    //now we have to devide fullname...
    $namearr = separateFullName($fullName);
    $order_id = $_GET['order_id'];
    $total_price = $_GET['total_payment'];


?>


    <div class="container mt-4">
      <form action="controllers/Payment_controller.php" method="post">

        <h3 class="mb-3">Personal Information</h3>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="firstName">First Name</label>
                <input value="<?php echo $namearr['first_name']; ?>" type="text" class="form-control" name="firstName" placeholder="First Name" required>
            </div>
            <div class="form-group col-md-6">
                <label for="lastName">Last Name</label>
                <input value="<?php echo $namearr['last_name']; ?>" type="text" class="form-control" name="lastName" placeholder="Last Name" required>
            </div>
        </div>



        <div class="form-group">
            <label for="email">Email Address</label>
            <input value="<?php echo $email; ?>" type="email" class="form-control" name="email" placeholder="Email Address" required>
        </div>

        <div class="form-group">
            <label for="address">Address</label>
            <input value="" type="text" class="form-control" name="address" placeholder="Address" required>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
            <label for="city">City</label>
            <input type="text" class="form-control" name="city" placeholder="City" required>
            </div>
            <div class="form-group col-md-4">
            <label for="state">State</label>
            <input type="text" class="form-control" name="state" placeholder="State" required>
            </div>
            <div class="form-group col-md-2">
            <label for="zip">Zip</label>
            <input value="" type="text" class="form-control" name="zip" placeholder="Zip" required>
            </div>
        </div>

        <h3>Payment Information</h3>
        <div class="form-group">
            <label for="paymentMethod">Payment Method</label>
            <select class="form-control" name="paymentMethod" required>
                <option value="">Select Payment Method</option>
                <option value="bkash">Bkash</option>
                <option value="togot">Nogot</option>
            </select>
        </div>

        <div class="form-group">
            <label for="phoneNumber">Phone Number</label>
            <input type="text" class="form-control" name="phoneNumber" placeholder="Phone Number" required>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
            <label for="transactionId">Transaction ID</label>
            <input type="text" class="form-control" name="transactionId" placeholder="Transaction ID" required>
            </div>
            <div class="form-group col-md-6">
            <label for="amount">Amount</label>
            <input value="<?php echo $total_price; ?>" type="text" class="form-control" name="amount" placeholder="Amount" required readonly>
            </div>
        </div>
        <input type="hidden" value="<?php echo $order_id; ?>" class="form-control" name="order_id" placeholder="Transaction ID" required>
        <button type="submit" class="btn btn-primary">Submit Payment</button>
      </form>
    </div>

<?php include('layouts/footer.php'); ?>