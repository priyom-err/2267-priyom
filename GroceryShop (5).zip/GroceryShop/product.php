<?php 

    include('layouts/header.php'); 
    require_once('controllers/ConnectionManager.php');

    if(!isset($_SESSION['username'])){
        header("Location: login.php");
    }


    $connectionManager = new ConnectionManager();
    $con = $connectionManager->getConnection();

    if (isset($_GET['id'])) {
        $product_id = $_GET['id'];

        if ($con) {
            $sql = "SELECT * FROM products WHERE product_id = $product_id";
            $result = mysqli_query($con, $sql);

            if ($result) {
                $row = mysqli_fetch_assoc($result);
                if ($row) {
                    // Product details
                    $product_name = $row['product_name'];
                    $product_description = $row['product_description'];
                    $product_price = number_format($row['product_price'], 2);
                    $product_quantity = $row['product_quantity'] > 0 ? 'In Stock' : 'Out of Stock';
                    $product_image = 'images/product_images/' . $row['product_image'];
                    $price_for_url = urlencode($product_price);

                    // Get the quantity value from the URL or set a default value
                    $quantity = isset($_GET['quantity']) ? intval($_GET['quantity']) : 1;
                                
                    ?>
                    <div class="container mt-5">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo $product_image; ?>" alt="Product Image" class="img-fluid">
                            </div>
                            <div class="col-md-6">
                                <h2><?php echo $product_name; ?></h2>
                                <p><?php echo $product_description; ?></p>
                                <p><strong>Price:</strong> BDT/=<?php echo $product_price; ?></p>
                                <p <?php if (isset($_GET['outofquontity'])) echo 'class="red-text"'; ?>><strong>Availability:</strong> <?php echo $product_quantity; ?></p>
                                <form class="order-form" method="post" action="controllers/Order_controller.php">
                                    <div class="form-group">
                                        <label for="quantity">Quantity:</label>
                                        <input type="number" class="form-control" id="quantity" name="quantity" min="1" value="<?php echo $quantity; ?>">
                                    </div>
                                    <input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
                                    <input type="hidden" name="price" value="<?php echo $price_for_url; ?>">
                                    <button name="orderbtn" type="submit" class="order-btn btn btn-primary">Order now</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php
                } else {
                    echo 'Product not found.';
                }
            } else {
                echo 'Error executing query: ' . mysqli_error($connection);
            }

            mysqli_free_result($result);
            mysqli_close($con);
        } else {
            echo 'Database connection failed.';
        }
    } else {
        echo 'Product ID not provided in the URL.';
    }

?>



<?php
    include('layouts/footer.php');
?>

