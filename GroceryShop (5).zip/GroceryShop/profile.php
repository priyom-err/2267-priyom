<?php 
    include('layouts/header.php'); 

    if(!isset($_SESSION['username'])){
        header("Location: login.php");
    }

    require_once 'controllers/ConnectionManager.php';
    $connectionManager = new ConnectionManager();
    $conn = $connectionManager->getConnection(); // Corrected variable name: $conn

    $username = $_SESSION['username'];

    function fetchOrderHistory($connection, $customer_username) {
        $orders = array();

        $sql = "SELECT * FROM orders WHERE customer_username = '$customer_username' ORDER BY order_date DESC";

        $result = mysqli_query($connection, $sql);

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $orders[] = $row;
            }

            mysqli_free_result($result);
        }

        return $orders;
    }
?>


    <div class="container mt-5">
        <div class="row">
            <div class="col-md-4">

            <?php 

                try {

                    $selectImageQuery = "SELECT image_path FROM user_profile WHERE username = ?";
                    $stmt = mysqli_prepare($conn, $selectImageQuery);

                    if (!$stmt) {
                        throw new Exception("Error preparing SQL statement: " . mysqli_error($conn));
                    }

                    mysqli_stmt_bind_param($stmt, "s", $username);

                    if (!mysqli_stmt_execute($stmt)) {
                        throw new Exception("Error executing SQL statement: " . mysqli_error($conn));
                    }

                    mysqli_stmt_bind_result($stmt, $imagePath);
                    mysqli_stmt_fetch($stmt);
                    mysqli_stmt_close($stmt);

                    // Remove the "../" from the image path
                    $imagePath = str_replace("../", "", $imagePath);

                    if ($imagePath && file_exists($imagePath)) {
                        echo '<img src="' . $imagePath . '" alt="User Profile" class="img-fluid profile-image">';
                    } else {
                        echo '<img src="images/account-default-icon.png" alt="User Profile" class="img-fluid profile-image">';
                    }
                } catch (Exception $e) {
                    // Handle the exception gracefully
                    echo '<img src="images/account-default-icon.png" alt="User Profile" class="img-fluid profile-image">';
                }
            ?>


                <form method="POST" action="controllers/Profile_Controller.php" enctype="multipart/form-data">
                    <input type="file" class="mt-2 form-control" name="profileImage" id="profileImage" accept="image/*">
                    <button name="updateProfilePic" class="btn btn-primary mt-2" id="updateProfile">Update Profile</button>
                </form>
            </div>
            <div class="col-md-8">
                
                <?php
                    // Assuming you have already established a database connection
                    $username = $_SESSION['username'];

                    try {
                        $query = "SELECT * FROM `user_profile` WHERE username=?";
                        $stmt = $conn->prepare($query);

                        if (!$stmt) {
                            throw new Exception("Error preparing SQL statement: " . $conn->error);
                        }

                        $stmt->bind_param("s", $username);

                        if (!$stmt->execute()) {
                            throw new Exception("Error executing SQL statement: " . $stmt->error);
                        }

                        $result = $stmt->get_result();

                        if ($result->num_rows > 0) {
                            $row = $result->fetch_assoc();
                            $fullName = $row['full_name'];
                            $dob = $row['dob'];
                            $bio = $row['bio'];
                        }
                    } catch (Exception $e) {
                       // $fullName = "Enter full name";
                       // $dob = "Enter date of birth";
                       // $bio = "Enter your BIO";   
                    }
                ?>


                <h2>User Details</h2>
                <form method="POST" action="controllers/Profile_Controller.php" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="fullName" class="form-label">Full Name</label>
                        <input type="text" class="form-control" name="fullName" id="fullName" value="<?php echo isset($fullName) ? $fullName : 'Enter full name'; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="date_of_birth" class="form-label">Birth Date</label>
                        <input type="date" class="form-control" name="date_of_birth" id="date_of_birth" value="<?php echo isset($date_of_birth) ? $date_of_birth : 'Enter date of birth'; ?>">
                    </div>
                    <div class="mb-3">
                        <label for="bio" class="form-label">Bio</label>
                        <textarea class="form-control" name="bio" id="bio"><?php echo isset($bio) ? $bio : 'Enter your BIO'; ?></textarea>
                    </div>
                    <button name="profile_info_update" type="submit" class="btn btn-primary">Save Changes</button>
                </form>


            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-12">
                <!-- Order History -->
                <h2>Order History</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order Date</th>
                            <th>Product id</th>
                            <th>Quantity</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                        if ($conn) {
                            $orderHistory = fetchOrderHistory($conn, $username);
                            if (!empty($orderHistory)) {
                                foreach ($orderHistory as $order) { ?>
                                    <tr>
                                        <td><?php echo $order['order_date']; ?></td>
                                        <td><?php echo $order['pid']; ?></td>
                                        <td><?php echo $order['quantity']; ?></td>
                                        <td><?php echo 'BDT/=' . $order['total_price']; ?></td>
                                    </tr>
                            <?php } ?>
                        <?php } ?>  
                    <?php } ?>       
                    </tbody>
                </table>
            </div>
        </div>
    </div>



    <?php include('layouts/footer.php'); ?>