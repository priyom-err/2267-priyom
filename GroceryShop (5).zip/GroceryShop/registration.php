<?php 
    include('layouts/header.php');
 ?>   

    <div class="container-fluid  mb-5">
        <div class="row">
            <div class="col-md-6 left-image d-flex justify-content-center align-items-center">
                <img class="registration-image" src="images/login.jpg">
            </div>
            <div class="col-md-6 d-flex align-items-center">
                <div class="container">
                    <div class="p-5">
                        <div class="card-heade">
                            <h3 class="text-left">Registration</h3>
                        </div>
                        <div class="card-bod">
                            <form method="POST" action="controllers/Authentication.php">
                                <div class="mb-3">
                                    <label for="username" class="form-label">Username</label>
                                    <input type="text" class="form-control" name="username" id="username" placeholder="Enter your username" required>
                                    <span class="error"><?php echo isset($_GET['reg_err']) && $_GET['reg_err'] == 1 && isset($_GET['usernameErr']) ? $_GET['usernameErr'] : ''; ?></span>
                                </div>
                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" name="email" id="email" placeholder="Enter your email" required>                                   
                                    <span class="error"><?php echo isset($_GET['reg_err']) && $_GET['reg_err'] == 1 && isset($_GET['emailErr']) ? $_GET['emailErr'] : ''; ?></span>
                                </div>
                                <div class="mb-3">
                                    <label for="password" class="form-label">Password</label>
                                    <input type="password" class="form-control" name="password" id="password" placeholder="Enter your password" required>
                                    <span class="error"><?php echo isset($_GET['reg_err']) && $_GET['reg_err'] == 1 && isset($_GET['passwordErr']) ? $_GET['passwordErr'] : ''; ?></span>
                                </div>
                                <div class="mb-3">
                                    <label for="confirmPassword" class="form-label">Confirm Password</label>
                                    <input type="password" class="form-control" name="confirmPassword" id="confirmPassword" placeholder="Confirm your password" required>
                                    <span class="error"><?php echo isset($_GET['reg_err']) && $_GET['reg_err'] == 1 && isset($_GET['confirmPasswordErr']) ? $_GET['confirmPasswordErr'] : ''; ?></span>
                                </div>
                                <div class="text-center">
                                    <button style="width: 100%;" name="regis_btn" type="submit" class="btn btn-primary">Register</button>
                                </div>
                            </form>
                            <div class="mt-3 text-center">
                                <p>Already have an account? <a style="color: orange;" href="login.php">Login here</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php include('layouts/footer.php'); ?>
