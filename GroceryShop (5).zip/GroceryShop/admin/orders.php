<?php 
    include('layouts/header.php');
    require_once('../controllers/ConnectionManager.php'); 

    $connectionManager = new ConnectionManager();
    $connection = $connectionManager->getConnection();

    function fetchOrders($connection) {
        $orders = array();

        $sql = "SELECT `id`, `pid`, `customer_username`, `quantity`, `total_price`, `status`, `order_date` FROM `orders` WHERE 1";
        $result = mysqli_query($connection, $sql);

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $orders[] = $row;
            }
        }

        return $orders;
    }


    if (isset($_POST['reject_order'])) {
        $order_id_to_reject = $_POST['order_id'];
        $update_sql = "UPDATE `orders` SET `status` = 'Rejected' WHERE `id` = '$order_id_to_reject'";
        if (mysqli_query($connection, $update_sql)) {
            header('Location: orders.php?reject_success');
        } else {
            echo 'Error rejecting the order: ' . mysqli_error($connection);
        }
    }


    if (isset($_POST['delete_order'])) {
        $order_id_to_delete = $_POST['order_id'];
        $delete_sql = "DELETE FROM `orders` WHERE `id` = '$order_id_to_delete'";
        if (mysqli_query($connection, $delete_sql)) {
            header('Location: orders.php?delete_success');
        } else {
            echo 'Error deleting the order: ' . mysqli_error($connection);
        }
    }

    $orders = fetchOrders($connection);
?>

<div class="order-list">
    <h3>Order List</h3>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Customer ID</th>
                <th>Product ID</th>
                <th>Order Date</th>
                <th>Quantity</th>
                <th>Total Amount</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($orders as $order) { ?>
                <tr>
                    <td><?php echo $order['id']; ?></td>
                    <td><?php echo $order['customer_username']; ?></td>
                    <td><?php echo $order['pid']; ?></td>
                    <td><?php echo $order['order_date']; ?></td>
                    <td><?php echo $order['quantity']; ?></td>
                    <td><?php echo 'BDT/=' . $order['total_price']; ?></td>
                    <td><?php echo $order['status']; ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                            <?php if ($order['status'] !== 'Rejected') { ?>
                                <button type="submit" name="reject_order" class="btn btn-warning">Reject</button>
                            <?php } ?>
                            <button type="submit" name="delete_order" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<?php 
    include('layouts/footer.php');
?>
