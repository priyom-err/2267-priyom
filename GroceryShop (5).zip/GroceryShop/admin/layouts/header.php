<?php

    $activePage = ''; 
    $currentPage = basename($_SERVER['PHP_SELF']);

    if ($currentPage === 'dashboard.php') {
        $activePage = 'dashboard';
    } elseif ($currentPage === 'add_product.php') {
        $activePage = 'add_product';
    } elseif ($currentPage === 'products.php') {
        $activePage = 'products';
    } elseif ($currentPage === 'users.php') {
        $activePage = 'users';
    } elseif ($currentPage === 'orders.php') {
        $activePage = 'orders';
    } elseif ($currentPage === 'message.php') {
        $activePage = 'message';
    }
?>


<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="./style/style.css">

    <title>Hello, world!</title>

    <!--Swiper link-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="../style/admin.css"/>
  </head>
<body>

</head>
<body>


    <div class="container-fluid">
        <div class="row">
            <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block sidebar">
                <div class="sidebar-logo text-center">
                    <img src="admin-logo.png" alt="Admin Logo" width="100">
                </div>
                <hr>
                <div class="sidebar-options">
                    <ul class="nav flex-column">
                    <li class="nav-item <?php echo ($activePage === 'dashboard') ? 'active-link' : ''; ?>">
                        <a class="nav-link" href="./dashboard.php">
                            <i class="fas fa-tachometer-alt"></i> Dashboard
                        </a>
                    </li>

                    <li class="nav-item <?php echo ($activePage === 'add_product') ? 'active-link' : ''; ?>">
                        <a class="nav-link" href="./add_product.php">
                            <i class="fas fa-plus-circle"></i> Add Product
                        </a>
                    </li>

                    <li class="nav-item <?php echo ($activePage === 'products') ? 'active-link' : ''; ?>">
                        <a class="nav-link" href="./products.php">
                            <i class="fas fa-cube"></i> Product Details
                        </a>
                    </li>

                    <li class="nav-item <?php echo ($activePage === 'users') ? 'active-link' : ''; ?>">
                        <a class="nav-link" href="./users.php">
                            <i class="fas fa-users"></i> Show Users
                        </a>
                    </li>

                    <li class="nav-item <?php echo ($activePage === 'orders') ? 'active-link' : ''; ?>">
                        <a class="nav-link" href="./orders.php">
                            <i class="fas fa-shopping-cart"></i> Order Details
                        </a>
                    </li>

                    <li class="nav-item <?php echo ($activePage === 'message') ? 'active-link' : ''; ?>">
                        <a class="nav-link" href="./message.php">
                            <i class="fas fa-envelope"></i> User Message
                        </a>
                    </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            

            <main class="col-md-9 col-lg-10 main-content">
                <div class="admin-info">
                    Admin Name
                    <a href="#" class="btn btn-danger btn-sm ml-2">Logout</a>
                </div>
