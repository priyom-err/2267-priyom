<?php
    include('layouts/header.php');
    require_once '../controllers/ConnectionManager.php';

    $connectionManager = new ConnectionManager();
    $connection = $connectionManager->getConnection();

    function fetchMessages($connection) {
        $messages = array();

        $sql = "SELECT `id`, `name`, `email`, `msg`, `date` FROM `messages` WHERE 1";
        $result = mysqli_query($connection, $sql);

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $messages[] = $row;
            }

            mysqli_free_result($result);
        }

        return $messages;
    }

    function removeMessage($connection, $messageId) {
        $sql = "DELETE FROM `messages` WHERE `id` = '$messageId'";
        return mysqli_query($connection, $sql);
    }

    if ($connection) {
        if (isset($_GET['remove']) && isset($_GET['id'])) {
            $messageIdToRemove = $_GET['id'];
            
            if (removeMessage($connection, $messageIdToRemove)) {
                header('Location: message.php?removesuccess');
            } else {
                header('Location: message.php?removefailed');
            }
        }

        $messagesData = fetchMessages($connection);
    }
?>

<div class="message-list">
    <?php
        if (isset($_GET['removesuccess'])) {
            $msg = 'Message removed successfully.';
            echo '<div class="demo_alert alert alert-success">' . htmlspecialchars($msg) . '</div>';
        }

        if (isset($_GET['removefailed'])) {
            $msg = 'Failed to remove message.';
            echo '<div class="demo_alert alert alert-danger">' . htmlspecialchars($msg) . '</div>';
        }
    ?>
    <h2>Message List</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Message</th>
                <th>Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
                if ($connection) {
                    foreach ($messagesData as $message) {
            ?>
            <tr>
                <td><?php echo $message['id']; ?></td>
                <td><?php echo $message['name']; ?></td>
                <td><?php echo $message['email']; ?></td>
                <td><?php echo $message['msg']; ?></td>
                <td><?php echo $message['date']; ?></td>
                <td>
                    <a href="?remove=1&id=<?php echo $message['id']; ?>" class="btn btn-danger remove-message">Remove</a>
                </td>
            </tr>
            <?php
                    }
                }
            ?>
        </tbody>
    </table>
</div>




<script>
    let demo_alert = document.getElementsByClassName('demo_alert')[0];

    setTimeout(() => {
        demo_alert.style.display = 'none';
    }, 2000);
</script>

<?php
    include('layouts/footer.php');
?>
