<?php 
    include('layouts/header.php');
    require_once '../controllers/ConnectionManager.php';

    $connectionManager = new ConnectionManager();
    $connection = $connectionManager->getConnection();
    $isAdministrator = true; 

    function fetchUserData($connection) {
        $userData = array();
    
        $sql = "SELECT user_profile.full_name, registration.email, user_profile.username, user_profile.bio, user_profile.date_of_create
                FROM user_profile
                INNER JOIN registration ON user_profile.username = registration.username
                WHERE 1;
                ";
        $result = mysqli_query($connection, $sql);
    
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $userData[] = $row;
            }
    
            mysqli_free_result($result);
        }
    
        return $userData;
    }
    
    function removeUser($connection, $username) {

        $sql1 = "DELETE FROM user_profile WHERE username = '$username'";
        $sql2 = "DELETE FROM registration WHERE username = '$username'";
        

        if (mysqli_query($connection, $sql1) && mysqli_query($connection, $sql2)) {
            return true;
        } else {
            return false;
        }
    }

    if (isset($_GET['remove']) && $_GET['remove'] == 1 && isset($_GET['id'])) {
        $userIdToRemove = $_GET['id'];
        
        if (removeUser($connection, $userIdToRemove)) {
           // echo "User removed successfully.";
            header('location: users.php?remsucc');
        } else {
           // echo "Failed to remove user.";
            header('location: users.php?remfailed');
        }
    }

?>

                <div class="product-list">
                    <?php
                        if (isset($_GET['remsucc'])) {
                            $msg = 'successfully removed';
                            echo '<div class="demo_alert alert alert-success">' . htmlspecialchars($msg) . '</div>';
                        }

                        if (isset($_GET['remfailed'])) {
                            $msg = 'failed to removed user';
                            echo '<div class="demo_alert alert alert-danger">' . htmlspecialchars($msg) . '</div>';
                        }
                    ?>
                    <h2>User List</h2>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Gmail</th>
                                <th>Username</th>
                                <th>Bio</th>
                                <th>Acc open date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php
                        if ($connection) {
                            $userData = fetchUserData($connection);
                            foreach ($userData as $user) {
                        ?>
                            <tr>
                                <td><?php echo $user['full_name']; ?></td>
                                <td><?php echo $user['email']; ?></td>
                                <td><?php echo $user['username']; ?></td>
                                <td><?php echo $user['bio']; ?></td>
                                <td><?php echo $user['date_of_create']; ?></td>
                                <?php if ($isAdministrator) { ?>
                                    <td>
                                        <a href="?remove=1&id=<?php echo $user['username']; ?>" class="btn btn-danger remove-product">Remove</a>
                                    </td>
                                <?php } ?>
                            </tr>
                        <?php
                            }
                        }
                        ?>
                            
                        </tbody>
                    </table>
                </div>


<script>
    let demo_alert = document.getElementsByClassName('demo_alert')[0];

    setTimeout(() => {
        demo_alert.style.display = 'none';
    }, 2000);
</script>
                
<?php 
    include('layouts/footer.php');
?>       