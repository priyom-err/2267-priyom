<?php 
  session_start();
  require_once 'controllers/ConnectionManager.php';

?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="./style/style.css">

    <title>FRESH SHOP</title>

    <!--Swiper link-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>

  </head>
  <body>

    <!-- Navbar container -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light d-flex justify-content-between align-items-center">

        <div class="">
          <a class="navbar-brand" href="index.php"><img class='hl-image' src="images/grocery-shop-logo.jpg"></a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
        </div>

        <hr id="draw-line">

        <div class="d-flex justify-content-between align-items-center">
          <div class="collapse navbar-collapse mr-4" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item active">
                <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="product_page.php">Product</a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Product Type
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                  <a class="dropdown-item" href="product_cata_page.php?cata='Fruits'">Fruits</a>
                  <a class="dropdown-item" href="product_cata_page.php?cata='Vegetables'">Vegetables</a>  
                  <a class="dropdown-item" href="product_cata_page.php?cata='Rice'">Rice</a>
                  <a class="dropdown-item" href="product_cata_page.php?cata='Spices'">Spices</a> 
                </div>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="contact.php" tabindex="-1" aria-disabled="true">Contact</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="about.php" tabindex="-1" aria-disabled="true">About</a>
              </li>
            </ul>
          </div>

          <div class="account-area">
            <div class="account-icon">
              <?php
                // Create a database connection
                $connectionManager = new ConnectionManager();
                $conn = $connectionManager->getConnection();

                if (!isset($_SESSION['username'])) {
                  echo '<img id="account-image" src="images/account-default-icon.png" alt="account default icon">';
                } else {
                  $username = $_SESSION['username'];

                  try {
                    $selectImageQuery = "SELECT image_path FROM user_profile WHERE username = ?";
                    $stmt = mysqli_prepare($conn, $selectImageQuery);

                    mysqli_stmt_bind_param($stmt, "s", $username);
                    mysqli_stmt_execute($stmt);
                    mysqli_stmt_bind_result($stmt, $imagePath);
                    mysqli_stmt_fetch($stmt);
                    mysqli_stmt_close($stmt);

                    // Remove the "../" from the image path
                    $imagePath = str_replace("../", "", $imagePath);

                    if ($imagePath && file_exists($imagePath)) {
                      echo '<img id="account-image" src="' . $imagePath . '" alt="account icon">';
                    } else {
                      echo '<img id="account-image" src="images/account-default-icon.png" alt="account default icon">';
                    }
                  } catch (mysqli_sql_exception $ex) {
                    echo '<img id="account-image" src="images/account-default-icon.png" alt="account default icon">';
                  }
                }
              ?>
            </div>

            <div class="pre-login" id="pre-login">
              <?php if(isset($_SESSION['username'])): ?>
                <a class="auth" href="profile.php">Profile</a>
                <a class="auth" href="./controllers/Authentication.php?logout=1">LogOut</a>
              <?php else: ?>
                <a class="not_auth" href="login.php">Sign In</a>
                <a class="not_auth" href="registration.php">Sign Up</a>
              <?php endif; ?>
            </div>
          </div><!--End of account area-->

        </div>
           
    </nav>


